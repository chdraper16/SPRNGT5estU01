/* This file is created by Makefile in SRC and incorporated in examples */
/* with the purpose of displaying generators names  and corresponding   */
/* numerals.                                                            */
  printf("Available generators; use corresponding numeral:\n");
        printf("   lfg     --- 0\n");
        printf("   lcg     --- 1\n");
        printf("   lcg64   --- 2\n");
        printf("   cmrg    --- 3\n");
        printf("   mlfg    --- 4\n");
        printf("   pmlcg   --- 5\n");
