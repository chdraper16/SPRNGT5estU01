C/* This file is created by Makefile in SRC and incorporated in examples */
C/* with the purpose of displaying generators names  and corresponding   */
C/* numerals.                                                            */
        print *, 'Available generators; use corresponding numeral:'
        print *, '   lfg     --- 0 '
        print *, '   lcg     --- 1 '
        print *, '   lcg64     --- 2 '
        print *, '   cmrg     --- 3 '
        print *, '   mlfg     --- 4 '
        print *, '   pmlcg     --- 5 '
