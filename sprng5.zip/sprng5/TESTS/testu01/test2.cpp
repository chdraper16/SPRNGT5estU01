#include <cmath>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "sprng_cpp.h"
#define SEED 985456376
#ifdef __cplusplus
extern "C"{
#endif 

#include "gdef.h"
#include "unif01.h"
#include "sres.h"
#include "sknuth.h"


#ifdef __cplusplus
}
#endif
#include <mpi.h>
#include <time.h>
Sprng *stream;

const double CV1[] = {0.995,0.929,0.829,0.734,0.669,0.617,0.576,0.542,0.513,0.489,0.468,0.449,0.432,0.418,0.404,0.392,0.381,0.371,0.361,0.352,0.344,0.337,0.330,0.323,0.317,0.311,0.305,0.300,0.295,0.290,0.285,0.281,0.277,0.273,0.269,0.265,0.262,0.258,0.255,0.252};

int qs(double *a, int min, int max)
{
double p;
int i,j;
int output;
double swap;
//printf("qs: %d %d\n",min,max);
if(min < max)
{
	p =a[max];
	i = min;
	for(int j = i;j < max;++j)
		if(a[j] < p)
		{swap = a[j];a[j]=a[i];a[i]=swap;++i;}
	swap = a[i]; a[i] = a[max]; a[max] = swap;
qs(a,min,i-1);
qs(a,i+1,max);
}
return 0;
}


double ks(double * data, int size)
{
qs(data,0,size-1);
//for(int i =0; i < size; ++i)
//	printf("%f\n",data[i]);

double max =  (data[0]-1.0/size < 1.0/size-data[0]) ? 1.0/size-data[0] : data[0]-1.0/size ;
double tmp;
for(int i = 1; i < size;++i)
{
tmp = (data[i]-(i+1.1)/size < (1.0+i)/size-data[i]) ? ((1.0+i)/size-data[i]) : (data[i]-(1.0+i)/size);
max = max > tmp ? max : tmp;
}
return max;
//D = Max of all elements(Max of (x_i- (i-1)/N,i/N-x_i))
}


double get_rn()
{
return stream->sprng();
}

int main()
{
srand(time(NULL));
int streamnum, nstreams;
  double rn;
  int i, myid, nprocs;
  int gtype;  /*---    */
	MPI_Status status;
	double * data;

  /*************************** MPI calls ***********************************/

  MPI_Init(NULL,NULL);	/* Initialize MPI                          */
  MPI_Comm_rank(MPI_COMM_WORLD, &myid);	/* find process id                 */
  MPI_Comm_size(MPI_COMM_WORLD, &nprocs); /* find number of processes      */

  /************************** Initialization *******************************/

  streamnum = myid;	
  nstreams = nprocs;		/* one stream per processor                */
/*--- node 0 is reading in a generator type */
  if(myid == 0)
  {
    gtype=0;
	data = new double[nstreams];
	printf("%d\n",nprocs);

}
else
fclose(stdout); 

  MPI_Bcast(&gtype,1,MPI_INT,0,MPI_COMM_WORLD );

  stream = SelectType(gtype);

  stream->init_sprng(streamnum,nstreams,0,SPRNG_DEFAULT);	/* initialize stream */

    
sres_Chi2 *info = sres_CreateChi2();
unif01_Gen *gen;
gen = unif01_CreateExternGen01((char*)"get_rn",get_rn);
sknuth_CouponCollector(gen,info,1,40000,0,4);

sres_GetChi2SumStat(info);
//printf("%f %d %f %d\n",info->pVal2[gofw_Sum],gofw_Sum,info->pVal2[gofw_Mean],gofw_Mean);
double pVal = info->pVal2[gofw_Mean];
if(myid !=0)
	{MPI_Send(&pVal,1, MPI_DOUBLE,0,0,MPI_COMM_WORLD);}
else
{data[0] = pVal;
	for(int i = 1; i <nstreams;++i)
		{MPI_Recv(data+i,nstreams,MPI_DOUBLE,i,0,MPI_COMM_WORLD,&status);}
}
if(myid==0)
	{/*for(int i = 0; i < nstreams;++i)printf("%d %f\n",i, data[i])*/;double ksv = ks(data,nstreams);double cv = nstreams<40 ? CV1[nstreams-1] : 1.63/sqrt(nstreams-1);
	printf("D: Value%f\tAlpha: .1: %f\t%s\n",ksv,cv,ksv <= cv ? "Passed" : "Failed");}


//printf("%d %f\n",streamnum,get_rn());
MPI_Finalize();
}

