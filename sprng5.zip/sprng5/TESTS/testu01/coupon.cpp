#if __GNUC__ > 3
 #include <iostream>
#else
 #include <iostream.h>
#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "tests.h"

#ifdef __cplusplus
extern "C"{
#endif 

#include "gdef.h"
#include "unif01.h"
#include "sres.h"
#include "sknuth.h"


#ifdef __cplusplus
}
#endif



int main(int argc, char *argv[])
{
  long ntests, n;
  int t, d;
  
  ntests = init_tests(argc,argv);
 
  n = atol(argv[N_STREAM_PARAM+1]);
  t = atoi(argv[N_STREAM_PARAM+2]);
  d = atoi(argv[N_STREAM_PARAM+3]);
  
  unif01_Gen *gen;
  gen = unif01_CreateExternGen01 ((char*)"get_rn", get_rn);
  //void sknuth_CouponCollector (unif01_Gen *gen, sres_Chi2 *res,long N, long n, int r, int d);
  sknuth_CouponCollector(gen, NULL,ntests,n,0,d);
  unif01_DeleteExternGen01(gen);
  return 0;
}