/*********************************************************************
       Gap Test
*********************************************************************/
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "tests.h"


#ifdef __cplusplus
extern "C"{
#endif 

#include "gdef.h"
#include "unif01.h"
#include "sres.h"
#include "sknuth.h"


#ifdef __cplusplus
}
#endif

using namespace std;

#define NUM_TEST_ENGIN_PARAM 4

int main(int argc, char *argv[]) {
	int     maxGapLen;
	double  lowerBound, upperBound;
	long    numTotGap;
	long    numRepeat;
	int  numParam=NUM_TEST_ENGIN_PARAM+N_STREAM_PARAM;

   if (argc<(numParam+1)) {
      printf("Error: %i number of parameters needed\n", numParam);
   }

   maxGapLen = atoi(argv[N_STREAM_PARAM+1]);
   lowerBound = atof(argv[N_STREAM_PARAM+2]);
   upperBound = atof(argv[N_STREAM_PARAM+3]);
   numTotGap = atol(argv[N_STREAM_PARAM+4]);
   
	numRepeat = init_tests(argc, argv);
    unif01_Gen *gen;
	gen = unif01_CreateExternGen01 ((char*)"get_rn", get_rn);
   //void sknuth_Gap (unif01_Gen *gen, sres_Chi2 *res,long N, long n, int r, double Alpha, double Beta)
   
   sknuth_Gap(gen,NULL, numRepeat, numTotGap/(upperBound-lowerBound), 0,lowerBound,upperBound);
   unif01_DeleteExternGen01(gen);

     return 0;
}
