#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include "tests.h"
#include <cmath>


using namespace std;

#ifdef __cplusplus
extern "C"{
#endif 

#include "gdef.h"
#include "sknuth.h"
#include "sres.h"
#include "unif01.h"


#ifdef __cplusplus
}
#endif


int main(int argc, char *argv[])
{
  long ntests, n;
  int logmd, logd;
  

  if(argc != N_STREAM_PARAM + 4)
  {
    fprintf(stderr,"USAGE: %s (... %d arguments)\n",argv[0], N_STREAM_PARAM+3);
    exit(1);
  }

  ntests = init_tests(argc,argv);
  
  n = atol(argv[N_STREAM_PARAM+1]);
  logmd = atoi(argv[N_STREAM_PARAM+2]);
  logd = atoi(argv[N_STREAM_PARAM+3]);

  
  unif01_Gen *gen;
  gen = unif01_CreateExternGen01 ((char*)"get_rn", get_rn);
//void sknuth_Collision (unif01_Gen *gen, sknuth_Res2 *res,long N, long n, int r, long d, int t);
 sknuth_Collision(gen, NULL, ntests, n,0,1<<logd,1<<(logmd-logd));
  unif01_DeleteExternGen01(gen);
  return 0;
}

