#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "tests.h"


#ifdef __cplusplus
extern "C"{
#endif 

#include "gdef.h"
#include "unif01.h"
#include "sres.h"
#include "sknuth.h"

#ifdef __cplusplus
}
#endif


double xt (double x);
double maxt (long n, int t);
void set_t (int t);
double *V2;

int xt_t = 1;


int main(int argc, char *argv[])
{
  long ntests, n;
  int t;
  
  if(argc != N_STREAM_PARAM + 3)
  {
    fprintf(stderr,"USAGE: %s (... %d arguments)\n",argv[0], N_STREAM_PARAM+2);
    exit(1);
  }
  
  ntests = init_tests(argc,argv);
  
  n = atol(argv[N_STREAM_PARAM+1]);
  t = atoi(argv[N_STREAM_PARAM+2]);
  
  unif01_Gen *gen;
  gen = unif01_CreateExternGen01 ((char*)"get_rn", get_rn);
	//that 2 at the end may not be sutable
  sknuth_MaxOft(gen, NULL,ntests,n,0,2,t);
unif01_DeleteExternGen01(gen);
  return 0;
}
