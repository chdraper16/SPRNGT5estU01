/*********************************************************************
       Run Test
*********************************************************************/

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "tests.h"


#ifdef __cplusplus
extern "C"{
#endif 

#include "gdef.h"
#include "unif01.h"
#include "sres.h"
#include "sknuth.h"


#ifdef __cplusplus
}
#endif

/* # of parameters for the test engin */
#define NUM_TEST_ENGIN_PARAM 2



int main(int argc, char *argv[]) {
  
   int  maxRunLen,numParam=NUM_TEST_ENGIN_PARAM+N_STREAM_PARAM;
   long numRepeat,numRun;
   if (argc!=(numParam+1)) {
      printf("Error: %i number of parameters needed\n", numParam);
      exit(1);
   }

   maxRunLen = atoi(argv[N_STREAM_PARAM+1]);
   numRun = atol(argv[N_STREAM_PARAM+2]);
   numRepeat = init_tests(argc, argv);

   unif01_Gen *gen;
   gen = unif01_CreateExternGen01 ((char*)"get_rn", get_rn);  
   sknuth_Run(gen,NULL,numRepeat,numRun,0,TRUE);
   unif01_DeleteExternGen01(gen);

    return 0;
}
