/* A two-dimensional random walk test based on the code of I. Vattulainen, 
   et al  */

#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include "tests.h"
#include <math.h>


using namespace std;


#ifdef __cplusplus
extern "C"{
#endif 

#include "unif01.h"
#include "swalk.h"

#ifdef __cplusplus
}
#endif



int main(int argc, char *argv[])
{
  long ntests, walk_length, i,l0,l1;
  double result, expected, chisum, quadrant[4];
  
  quadrant[0] = quadrant[1] = quadrant[2] = quadrant[3] = 0;
  
  if(argc != N_STREAM_PARAM + 4 && argc != N_STREAM_PARAM + 2)
  {
    fprintf(stderr,"USAGE: %s (... %d or %d arguments)\n",argv[0], N_STREAM_PARAM+1,N_STREAM_PARAM+3);
    exit(1);
  }
  
  ntests = init_tests(argc,argv);
  
  walk_length = atoi(argv[N_STREAM_PARAM+1]);
  if(argc == N_STREAM_PARAM+4){
  l0 = atoi(argv[N_STREAM_PARAM+2]);
  l1 = atoi(argv[N_STREAM_PARAM+3]);
  }
  else
	l0 = l1 = walk_length;
  unif01_Gen *gen;
  gen = unif01_CreateExternGen01 ((char*)"get_rn", get_rn);

  swalk_RandomWalk1(gen, NULL,ntests,walk_length,0,sizeof(double),l0,l1);
  //void swalk_RandomWalk1 (unif01_Gen *gen, swalk_Res *res, long N, long n,int r, int s, long L0, long L1);
  unif01_DeleteExternGen01(gen);
 

  return 0;
}



