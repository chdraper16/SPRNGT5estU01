/*********************************************************************
       Permutation Test
*********************************************************************/
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "tests.h"


#ifdef __cplusplus
extern "C"{
#endif 

#include "gdef.h"
#include "unif01.h"
#include "sres.h"
#include "sknuth.h"


#ifdef __cplusplus
}
#endif

using namespace std;

/* # of parameters for the test engin */
#define NUM_TEST_ENGIN_PARAM 2


int main(int argc, char *argv[]) {
    int  numParam=NUM_TEST_ENGIN_PARAM+N_STREAM_PARAM;
	int grpSize;
	long numGrp, numRepeat;
   if (argc<(numParam+1)) {
      printf("Error: %i number of parameters needed\n", numParam);
      exit(1);
   }

   grpSize = atoi(argv[N_STREAM_PARAM+1]);
   numGrp = atol(argv[N_STREAM_PARAM+2]);
   numRepeat = init_tests(argc,argv);

  unif01_Gen *gen;
  gen = unif01_CreateExternGen01 ((char*)"get_rn", get_rn);
  sknuth_Permutation(gen,NULL,numRepeat,numGrp,0,grpSize);
unif01_DeleteExternGen01(gen);
     return 0;
}
