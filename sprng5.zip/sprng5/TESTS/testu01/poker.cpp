#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "tests.h"
#include <math.h>

using namespace std;

#ifdef __cplusplus
extern "C"{
#endif 

#include "gdef.h"
#include "unif01.h"
#include "sres.h"
#include "sknuth.h"


#ifdef __cplusplus
}
#endif



int main(int argc, char *argv[])
{
  long ntests, n;
  int k, d;
  
  if(argc != N_STREAM_PARAM + 4)
  {
    fprintf(stderr,"USAGE: %s (... %d arguments)\n",argv[0], N_STREAM_PARAM+3);
    exit(1);
  }
  
  ntests = init_tests(argc,argv);
  
 
  n = atol(argv[N_STREAM_PARAM+1]);
  k = atoi(argv[N_STREAM_PARAM+2]);
  d = atoi(argv[N_STREAM_PARAM+3]);
  
  unif01_Gen *gen;
  gen = unif01_CreateExternGen01 ((char*)"get_rn", get_rn);
  sknuth_SimpPoker(gen,NULL,ntests,n,0,d,k);
unif01_DeleteExternGen01(gen);
  return 0;
}
